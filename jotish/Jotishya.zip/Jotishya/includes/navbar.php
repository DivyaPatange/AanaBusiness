  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top " style="background-color: #07273c;">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">Goforjotish</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.html">Home</a></li>
          <li class="drop-down"><a href="#about">Horoscope</a>
          <ul>
              <li><a href="#">Daily Horoscope</a></li>
              <li><a href="#">Weekly Horoscope</a> </li>
              <li><a href="#">Monthly Horoscope</a></li>
              <li><a href="#">Yearly Horoscope</a></li>
              
            </ul>
</li>
          <li><a href="#services">Gemstones</a></li>
          
          <li><a href="#portfolio">Remedies</a></li>
          <li class="drop-down"><a href="#team">Astrology</a>
          <ul>
              <li><a href="#">Vedic Astrology</a></li>
              <li><a href="#">Child Astrology</a> </li>
              <li><a href="#">Numerlogy</a></li>
              <li><a href="#">Vastu Services</a></li>
              
            </ul>
        </li>
          <li class="drop-down"><a href="">Forecast</a>
            <ul>
              <li><a href="#"> Aries</a></li>
             <li><a href="#">Taurus</a></li>
              <li><a href="#">Gemini</a></li>
              <li><a href="#">Cancer</a></li>
              <li><a href="#">Leo</a></li>
              <li><a href="#"> Vigro</a></li>
              <li><a href="#">Libra</a></li>
             
            </ul>
          </li>
          <li><a href="#contact">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

      <a href="#about" class="get-started-btn scrollto">Appointement</a>

    </div>
  </header><!-- End Header -->


